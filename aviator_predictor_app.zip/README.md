# Aviator Predictor App
This is the Aviator Predictor App source code.